# Mastermind — Phase I

From this directory, compile and run:

```sh
mkdir -p build
javac -Xlint:all -d build assignment2/*.java
java -cp build assignment2.Driver mastermind
java -cp build assignment2.Driver mastermind test
java -cp build assignment2.MasterMindRulesTest
java -cp build assignment2.TestHarness
```

For IDE package resolution, use `project2_au4355` as the Java source root; its child `assignment2` is the package. The extensionless `assignment2/GuessingGame` is an earlier draft, not a compiled Java source. The implementation is `GuessingGame.java`.

Test mode reveals a deterministic code by cycling through the configured colors (BGOP by default). Normal mode selects each peg independently and permits repeats. Change the configuration constructed in Driver to adjust code length, attempts, or the legal symbols.

## Design

`Driver` selects and launches Mastermind. `GameConfiguration` stores and validates Mastermind settings. `MastermindRules` validates codes and scores exact matches before matching remaining pegs. `GuessRecord` holds immutable Mastermind feedback.

`GuessRules` and `GuessFeedback` define the reusable validation, evaluation, and result contracts. `GuessingGame` owns attempts, ordered history, console input, win/loss, and replay. `MastermindGame` extends it with configuration, code generation, and Mastermind prompts. History reads the feedback interface directly, so another result type does not need a particular `toString()` implementation.

The shared loop currently assumes string guesses and uppercase, trimmed console input. A future game with case-sensitive input would require adapting that choice. No Wordle implementation is included because the provided requirements specify Phase I only.

## Validation

The original test suite has 11 checks. TestHarness adds 245 checks, including 200 reproducible generated scoring cases over 1–10 pegs and 1–10 colors. Its independent oracle counts color frequencies and subtracts exact matches from total matches.

Coverage includes duplicate colors, invalid guess and secret arguments, configuration validation, empty and populated history, attempt accounting, wins, losses, replay and history reset, invalid replay responses, EOF, five-peg configuration, test-mode disclosure, and Turkish-locale input handling. Tests throw AssertionError on failure; Java's `-ea` flag is unnecessary.

## AI assistance

OpenAI Codex completed the partial shared-loop integration, corrected the GuessRecord constructor call, and added regression tests. It retained the existing two-pass scoring algorithm. An inherited design choice—rendering history through each result's `toString()`—was changed to use the explicit GuessFeedback methods so the shared loop depends only on its declared interface.

Existing PDFs and the original ZIP predate these changes and have not been regenerated. This README documents the current implementation and validation.
